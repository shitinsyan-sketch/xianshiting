# English Practice Summary

- **Date (Asia/Shanghai):**
- **Mode:**
- **Topic:**
- **Session duration:** Exact / user-provided / estimated / unavailable
- **Today's total duration (00:00–24:00 Beijing time):** Exact / user-provided / estimated / unavailable
- **Timing note:** Include source of duration. If unknown, say it could not be verified; do not guess.

## 1. What we practiced
- 

## 2. Corrections
| Learner's version | Corrected English | Brief explanation |
|---|---|---|
| | | |

## 3. Useful expressions
| English | 中文 | Example | Category |
|---|---|---|---|
| | | | |

## 4. Performance
- **What went well:**
- **Priority to improve:**

## 5. Review plan
| Review date | Items | Status |
|---|---|---|
| Day 1 | | Pending |
| Day 4 | | Pending |
| Day 7 | | Pending |
| Day 14 | | Pending |

## 6. Next session
- **Suggested topic/question:**
