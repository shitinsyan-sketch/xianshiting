# Weekly English Progress Review

- **Review period:**
- **Learner's main goal:**
- **Target deadline (if any):**
- **Practice sessions completed / planned:**
- **Evidence used:** current conversation / practice log / learner-provided notes

## 1. What improved
- 

## 2. Recurring challenges (up to 3)
- 

## 3. Goal status
- **Status:** On track / Needs adjustment / Insufficient evidence
- **Reason:**

## 4. Next week's priorities
1. 
2. 
3. 

## 5. Plan adjustments
- **Increase:**
- **Reduce:**
- **Keep:**

## 6. One measurable target
- 

## 7. Learner feedback
- **What felt useful?**
- **What should change?**
