# English Speaking Practice Skill

一个可复用的英语口语练习 Skill，适用于日常英语、商务英语、求职面试，以及“中文提示 → 英文作答”练习。

## Features

- **先了解学习目标**：首次练习先询问学习英语的目的、目标和实际使用场景。
- **个性化练习计划**：根据目标、当前水平、截止日期和可投入时间，制定可执行的阶段计划，并根据进展调整。
- **不打断学习者**：学习者正在组织语言或停顿时，先等待，不抢答、不插话。
- **一次一个问题**：从真实对话和面试问题开始，而不是一次灌输大量词汇。
- **完成后纠错**：先让学习者尝试，再指出关键错误、给出自然表达和简短解释。
- **中英双语记录**：收集实用表达、中文释义、例句和主题分类。
- **练习总结**：记录主题、纠错、重点表达、表现反馈和后续复习安排。
- **间隔复习**：建议按第 1、4、7、14 天复习。
- **每周进度评估**：根据真实练习记录复盘进步、常见问题和目标完成情况，并调整下一周的练习重点。
- **时间不造假**：练习时长按北京时间自然日累计，目标是从打开语音聊天到结束聊天的实际经过时间；如果平台没有提供可靠时间戳，就明确标记无法准确获取，不用猜测值冒充精确值。

## Repository structure

```text
english-speaking-practice-skill/
├── SKILL.md
├── README.md
├── LICENSE
└── templates/
    ├── session-summary.md
    └── practice-log.csv
```

## How to use

1. 将整个 `english-speaking-practice-skill` 文件夹放入你所使用的、支持 Agent Skills 的 AI 工具的 skills 目录。
2. 在对话中启用/调用 `english-speaking-practice` skill（具体启用方式取决于平台）。
3. 告诉 AI 你想练习的模式，例如：
   - `Let's practice daily English.`
   - `Please interview me for an overseas marketing role. Ask one question at a time.`
   - `请进行中文提示、我用英文回答的练习。`
4. 每次练习结束时，要求 AI 按 `templates/session-summary.md` 输出总结，并将记录复制到自己的日志中，或在支持文件写入的环境中更新日志。

> 注意：Skill 是一组行为指令，不会自动获得麦克风事件、准确的语音聊天开始/结束时间、定时推送或持久化存储能力。这些能力取决于宿主平台。除非平台提供可靠时间戳或你主动提供时长，否则不得编造精确练习时长。定时提醒也需要单独配置并验证。

## Recommended workflow

1. **首次使用：明确目标。** 先说明为什么学习英语、希望达到什么结果，例如准备英文面试、提升商务沟通或旅行交流。
2. **制定个人计划。** AI 根据目标、当前水平、薄弱点、截止日期和每周可用时间，设计阶段目标、每周安排和练习主题。
3. 每次只练一个问题，先尝试回答。
4. 回答结束后再看纠错和自然表达。
5. 每次结束保存总结。
6. 下次练习先复习到期表达，再开始新问题。
7. 每周回顾常犯错误，选择 1–3 个重点改进，并按实际进展调整计划。
8. 每 7 天进行一次阶段评估：检查目标进度、表达准确度、词汇使用和练习完成情况，制定下一周的重点与一个可衡量的小目标。

## Customization

Edit `SKILL.md` to change the preferred language, correction detail, practice modes, or review cadence. Keep the “do not interrupt” and “do not fabricate timing or experience” rules if they are important to your workflow.

## License

MIT. See `LICENSE`.
